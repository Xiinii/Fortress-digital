function fetchData() {
  fetch("data.json")
    .then(response => response.json())
    .then(data => {

      if (data.title && Array.isArray(data.title)) {
        var value = "";
        data.title.forEach(item => {
          value += "<br>" + item;
        });

        createContent(value, null);
      }


      if (data.details && Array.isArray(data.details)) {
        data.details.forEach(item => {
          var value = "";
          
          if (isNaN(item.value)) {
            value = item.value[0].toUpperCase() + item.value.substring(1);
          }
          else {
            value = convertCurrency(item.value.toString());
          }
          createContent(item.name[0].toUpperCase() + item.name.substring(1), value);
        });
      }

      if (data.address) {
        var value = data.address.street + ", <br>" + data.address.zipCode + " " + data.address.city;
        createContent("Adresse", value);
      }

      if (data.contact) {
        var value = data.contact.name + "<br>" + convertPhoneNumber(data.contact.phone);
        createContent("Kontakt", value);
      }
    });
}




function convertCurrency(currency) {
  var returnValue = currency;
  if (currency.length == 5){
    returnValue = currency.substring(0, 2) + "." + currency.substring(2);
  }
  if (currency.length == 6) {
    returnValue = currency.substring(0, 3) + "." + currency.substring(3);
  }
  if (currency.length == 7) {
    returnValue = currency.substring(0, 1) + "." + currency.substring(1, 4) + "." + currency.substring(4);
  }
  if (currency.length == 8) {
    returnValue = currency.substring(0, 2) + "." + currency.substring(2, 5) + "." + currency.substring(5);
  }
  return returnValue + ",-";
}


function convertPhoneNumber(phoneNumber) {
  var returnValue = "+47 " + phoneNumber.substring(0, 3)
  +" " + phoneNumber.substring(3, 5) + " " + phoneNumber.substring(5, 8);
  return returnValue;
}




function createContent(title, content) {
  let itemContainer = document.createElement("div");
  if (content == null) {
      itemContainer.classList.add("itemTitle");
    itemContainer.innerHTML = `<h2>${title}</h2>`;
  }
  else if (title == "Adresse" || title == "Kontakt"){
          itemContainer.classList.add("itemBottom");
          itemContainer.innerHTML = `<h2 id="left">${title}</h2><br><br><h2 id="left-oneline">${content}</h2>`;
  }
  else {
      itemContainer.classList.add("itemContainer");
      itemContainer.innerHTML = `<div class="text"><h2 id="left">${title}</h2> <h2 id="right">${content}</h2></div>`;
  }
   valuesContainer.appendChild(itemContainer);
}

fetchData();
