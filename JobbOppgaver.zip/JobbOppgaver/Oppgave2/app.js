
fetch("data.json")
  .then(response => response.json())
  .then(data => {
    var array = data.filter (function (item) {
      return item.description != "" && item.description != "0"
      && item.description != "nei" && item.description != "false"
    });
      
    array.sort((a, b) => {
        return a.value - b.value;
    });

    const string = JSON.stringify(array);
    document.querySelector(".output").innerHTML = string;
  })

  .catch(error => console.error(error));
  
